# Chae-Hoon Lee portfolio – downloadable CV & Publications

## GitHub Pages 배포

GitHub 저장소 `jaguar200613-cyber/chaehoon-portfolio`의 `main` 브랜치 최상위에 있는 `index.html`을 이 폴더의 `index.html`로 교체하세요. 기존 README는 유지해도 됩니다. GitHub Pages 설정에서 `main` / `(root)` 선택 시 사이트가 배포됩니다.

**단일 HTML 배포:** index.html 내부에 원본 PDF 두 개를 포함했으므로 별도 PDF 파일 없이도 사이트에서 두 파일을 다운로드할 수 있습니다. `documents/` 안의 PDF는 개별 보관·공유용이며, 홈페이지 동작에 필수는 아닙니다.

## 업데이트한 기능
- 메인 화면의 CV · Publication List 빠른 다운로드 링크
- Research/Publications 영역의 아이콘이 있는 다운로드 카드 2개
- 한국어/영어 전환 및 모바일 레이아웃 지원
- CV 및 Publication List PDF 원본 파일 내려받기

## 공개에 관한 주의
CV 원본에는 연락처 등 개인정보가 포함될 수 있습니다. 공개 배포 전에 문서 내용을 확인하세요.
